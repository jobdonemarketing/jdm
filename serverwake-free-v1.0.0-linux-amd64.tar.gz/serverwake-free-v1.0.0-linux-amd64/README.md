# Serverwake Free

A minimal service watchdog for Ubuntu servers.

Serverwake Free watches a built-in catalogue of delivery-layer
services — nginx, PHP-FPM, Redis, MariaDB, Docker, ClamAV, Fail2ban,
and similar — and restarts them if they fail. That is the entire
product. No dashboards, no alerts to tune, no integrations to wire
up. Just a binary that runs forever and restarts what breaks.

It is the free, Apache-2.0-licensed version of a larger paid product.
It is not crippled; it is complete for its scope.

## What it watches

A built-in catalogue of common delivery-layer services:

- Web servers: `nginx`, `apache2`
- Application runtimes: `php*-fpm`, `gunicorn`, `uwsgi`
- Caches and data stores: `redis-server`, `memcached`, `mariadb`, `mysql`, `postgresql@*-main`
- Containers: `docker`
- Security and integrity: `clamav-daemon`, `fail2ban`
- File transfer: `pure-ftpd`
- Process supervision: `supervisor`

Entries with `*` are globs: `php*-fpm` matches `php8.3-fpm`, `php8.4-fpm`, and so on. At startup, Serverwake resolves the catalogue against systemd and watches only the services that are present.

Serverwake does not watch OS plumbing (`systemd-*`, `dbus`, `cron`, `rsyslog`, `getty`, `polkit`, `ssh`) or hardware management (`ModemManager`, `multipathd`, `udisks2`). If those fail, the system is unhealthy — that is out of scope for a service watchdog.

## What it does

On every 60-second tick, Serverwake checks each watched service. If a service is in the `failed` state, it is restarted. Nothing else happens.

**Deliberate stops are respected.** If you run `systemctl stop nginx`, Serverwake does not restart it. Only `failed` services are restarted. Only interventions are logged.

## Install

Four commands. Run as root.


    sudo install -m 755 -o root -g root serverwake-free /usr/local/bin/serverwake-free
    sudo install -m 644 -o root -g root serverwake-free.service /etc/systemd/system/serverwake-free.service
    sudo touch /var/log/serverwake-free.log
    sudo chown admin:admin /var/log/serverwake-free.log
    sudo chmod 644 /var/log/serverwake-free.log
    sudo systemctl daemon-reload
    sudo systemctl enable --now serverwake-free

Replace `admin:admin` with the user and group that should own the log on your system. The service runs as root; the log is owned by you, so you can read it without `sudo`.

## Check that it is running

    systemctl status serverwake-free

## Read the log

    cat /var/log/serverwake-free.log

The log contains only interventions — moments when Serverwake restarted a service, or tried to and failed. If the log is empty, everything is fine.

## After installing or removing a service

The catalogue is resolved at startup. If you install a new version of a catalogued service (for example, `php8.4-fpm` alongside `php8.3-fpm`) or remove one, tell Serverwake to re-scan:

    sudo systemctl reload serverwake-free

Serverwake will re-resolve the catalogue and log the new watch list. This is not automatic — by design. The sysadmin knows when the service landscape changes.

## Uninstall

    sudo systemctl stop serverwake-free
    sudo systemctl disable serverwake-free
    sudo rm /etc/systemd/system/serverwake-free.service
    sudo rm /usr/local/bin/serverwake-free
    sudo systemctl daemon-reload

The log file at `/var/log/serverwake-free.log` is left in place. Delete it manually if you want.

## What it does not do

Serverwake Free deliberately omits:

- Configuration file (the catalogue is built-in)
- Dashboard, web or terminal
- Pause or resume
- Email, Slack, webhook, or any notification
- HTTP health checks
- Process-state or I/O monitoring
- Disk cleanup
- ClamAV self-tests
- Docker container restarts (only the `docker` service itself)
- System health checks (load, memory, disk)
- Suspension on degraded systemd state
- Telemetry, update checks, or any network traffic

Every one of these is either a paid-version feature or explicitly out of scope. The paid version adds a config file, a read-only dashboard, a TTY pause system, smart detectors, and vendor support.

## Log rotation

A `logrotate` configuration is included. Install it with:

    sudo install -m 644 -o root -g root serverwake-free.logrotate /etc/logrotate.d/serverwake-free

Then logrotate will manage the log automatically. Weekly rotation, four weeks retained, compressed.

## License

Apache 2.0. See `LICENSE`.

## What it finds on a typical server

On a standard Ubuntu 24.04 web server running a common LEMP stack,
Serverwake resolves the catalogue to something like:

    nginx
    php8.x-fpm
    redis-server
    memcached
    mariadb
    fail2ban
    pure-ftpd
    supervisor

Eight services. That is what Serverwake watches. Every 60 seconds it
checks each one, and if any is in the `failed` state, it restarts it
and writes one line to the log.

On the same server, these catalogue entries may match nothing and are
silently skipped:

    apache2
    gunicorn
    uwsgi
    mysql
    postgresql@*-main
    docker
    clamav-daemon

They are in the catalogue because other servers run them. Serverwake
is designed to work on any Ubuntu box with any combination of common
delivery-layer services. It watches what is present and ignores what
is not. No configuration required.

After installing or removing a service, tell Serverwake to re-scan:

    sudo systemctl reload serverwake-free

It will re-resolve the catalogue and log the new watch list.
