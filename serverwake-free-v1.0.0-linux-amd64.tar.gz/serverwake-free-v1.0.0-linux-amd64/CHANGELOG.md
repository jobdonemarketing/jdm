# Changelog

## 1.0.0 — 2026-09-25

Initial release.

- Watches a built-in catalogue of delivery-layer services
- Auto-detects which services are present at startup
- Supports version globs (e.g. `php*-fpm`, `postgresql@*-main`)
- Restarts services in the `failed` state
- Respects deliberate stops (`systemctl stop` is not a failure)
- Logs only interventions; silent on normality
- Reloads the catalogue on SIGHUP (`systemctl reload serverwake-free`)
- Single static binary, no runtime dependencies
- Apache 2.0 license
